# CS Final sem 2

A Pen created on CodePen.

Original URL: [https://codepen.io/wolymbps-the-selector/pen/jEEYgyd](https://codepen.io/wolymbps-the-selector/pen/jEEYgyd).

